﻿namespace BSL.v41.Logic.LHelp;

public static class StaticOnGetService
{
    public static OnGetMessagesHelper OnGetMessagesHelper = null!;
}