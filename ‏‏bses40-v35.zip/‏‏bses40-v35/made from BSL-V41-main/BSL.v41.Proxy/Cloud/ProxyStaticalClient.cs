﻿using BSL.v41.Proxy.Network;

namespace BSL.v41.Proxy.Cloud;

public static class ProxyStaticalClient
{
    public static ProxySocketTransportClient ProxySocketTransportClient = null!;
}