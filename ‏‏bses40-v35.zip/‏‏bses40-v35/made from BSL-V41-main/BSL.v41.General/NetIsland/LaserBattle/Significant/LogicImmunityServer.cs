﻿namespace BSL.v41.General.NetIsland.LaserBattle.Significant;

public class LogicImmunityServer
{
    // todo.
}